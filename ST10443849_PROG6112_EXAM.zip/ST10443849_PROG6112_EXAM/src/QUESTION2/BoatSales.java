package QUESTION2;

import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;
import java.nio.file.*;

public class BoatSales implements IBoatSales {

    @Override
    public double CalculateTotal(double boatPrice) {
        return boatPrice * 1.14; 
    }

    @Override
    public boolean ValidateData(BoatSalesData boatSalesData) {
        return !boatSalesData.boatType.isEmpty() && boatSalesData.boatPrice > 0;
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("BOAT SALES");
        frame.setSize(500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        
        JLabel boatLabel = new JLabel("SELECT BOAT TYPE:");
        boatLabel.setBounds(50, 20, 150, 25);
        frame.add(boatLabel);

        JLabel unitPriceLabel = new JLabel("BOAT PRICE:");
        unitPriceLabel.setBounds(50, 60, 150, 25);
        frame.add(unitPriceLabel);

        JLabel reportLabel = new JLabel("TICKET REPORT:");
        reportLabel.setBounds(50, 100, 150, 25);
        frame.add(reportLabel);

        // ComboBox for Boat Selection
        JComboBox<String> boatComboBox = new JComboBox<>(new String[]{"Bowrider", "Catamaran"});
        boatComboBox.setBounds(200, 20, 200, 25);
        frame.add(boatComboBox);

        // Text Field for Price
        JTextField unitPriceField = new JTextField();
        unitPriceField.setBounds(200, 60, 200, 25);
        frame.add(unitPriceField);

        // Text Area for Report
        JTextArea reportArea = new JTextArea();
        reportArea.setBounds(50, 140, 400, 150);
        reportArea.setEditable(false);
        frame.add(reportArea);

        // Menu System
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenu toolsMenu = new JMenu("Tools");

        JMenuItem exitItem = new JMenuItem("Exit");
        JMenuItem processReportItem = new JMenuItem("Process Report");
        JMenuItem clearItem = new JMenuItem("Clear");
        JMenuItem saveReportItem = new JMenuItem("Save Report");

        fileMenu.add(exitItem);
        toolsMenu.add(processReportItem);
        toolsMenu.add(clearItem);
        toolsMenu.add(saveReportItem);
        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        frame.setJMenuBar(menuBar);

        // BoatSales instance to handle operations
        BoatSales boatSales = new BoatSales();

        // Event Handlers
        exitItem.addActionListener(e -> System.exit(0));

        processReportItem.addActionListener(e -> {
            String selectedBoat = (String) boatComboBox.getSelectedItem();
            double boatPrice;

            try {
                
                boatPrice = Double.parseDouble(unitPriceField.getText().trim());

                
                BoatSalesData boatSalesData = new BoatSalesData(selectedBoat, boatPrice);

                
                if (!boatSales.ValidateData(boatSalesData)) {
                    JOptionPane.showMessageDialog(frame, "Please ensure all fields are valid:\n- Boat Type cannot be empty.\n- Boat Price must be greater than zero.");
                    return;
                }

                
                double totalPriceWithVAT = boatSales.CalculateTotal(boatPrice);

                // Display the report
                String report = String.format(
                    "Boat Type: %s%nBoat Price: R%.2f%nTOTAL BOAT PRICE with 14%% VAT: R%.2f",
                    selectedBoat, boatPrice, totalPriceWithVAT
                );
                reportArea.setText(report);

                
                System.out.println("Selected Boat: " + selectedBoat);
                System.out.println("Boat Price: R" + boatPrice);
                System.out.println("Total Price (with VAT): R" + totalPriceWithVAT);

            } catch (NumberFormatException ex) {
                // Handle invalid number input
                JOptionPane.showMessageDialog(frame, "Please enter a valid number for the boat price.");
            }
        });

        clearItem.addActionListener(e -> {
            boatComboBox.setSelectedIndex(0);
            unitPriceField.setText("");
            reportArea.setText("");
        });

        saveReportItem.addActionListener(e -> {
            try {
                Files.write(Paths.get("boat_sales_report.txt"), reportArea.getText().getBytes());
                JOptionPane.showMessageDialog(frame, "Report saved to boat_sales_report.txt");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(frame, "Error saving report: " + ex.getMessage());
            }
        });

        frame.setVisible(true);
    }
}

class BoatSalesData {
    String boatType;
    double boatPrice;

    public BoatSalesData(String boatType, double boatPrice) {
        this.boatType = boatType;
        this.boatPrice = boatPrice;
    }
}

interface IBoatSales {
    double CalculateTotal(double boatPrice);

    boolean ValidateData(BoatSalesData boatSalesData);
}
