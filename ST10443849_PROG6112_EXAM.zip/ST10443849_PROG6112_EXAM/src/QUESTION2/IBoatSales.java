package QUESTION2;

public interface IBoatSales {
	double CalculateTotal(double boatPrice);
	boolean ValidateData(BoatSales boatSalesData);

}
