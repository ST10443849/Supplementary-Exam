package QUESTION2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculateTotalBoatPrice_CalculatedSuccessfully {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
