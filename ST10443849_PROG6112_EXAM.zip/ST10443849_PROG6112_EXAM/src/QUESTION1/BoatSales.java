package QUESTION1;




public class BoatSales implements IBoatSales {

 // Method to calculate total sales for a specific boat 
 public int TotalBoatSales(int[] boatSales) {
     int total = 0;
     for (int sales : boatSales) {
         total += sales;
     }
     return total;
 }

 
 @Override
 public String TopSellingBoat(String[] boats, int[] totalSales) {
     int maxSales = totalSales[0];
     int maxIndex = 0;
     for (int i = 1; i < totalSales.length; i++) {
         if (totalSales[i] > maxSales) {
             maxSales = totalSales[i];
             maxIndex = i;
         }
     }
     return boats[maxIndex];
 }

 
 public static void main(String[] args) {
     // Boat types and sales data
     String[] boats = {"Bowrider", "Catamaran"};
     int[][] salesData = {
         {3, 1, 5}, // Bowrider sales for Jan, Feb, Mar
         {3, 2, 6}  // Catamaran sales for Jan, Feb, Mar
     };

     
     BoatSales boatSales = new BoatSales();

     
     int[] totalSales = new int[boats.length];
     for (int i = 0; i < boats.length; i++) {
         totalSales[i] = boatSales.TotalBoatSales(salesData[i]);
     }

     
     System.out.println("BOAT SALES REPORT");
     System.out.println("             JAN    FEB    MAR");
     for (int i = 0; i < boats.length; i++) {
         System.out.printf("%-10s", boats[i]);
         for (int sales : salesData[i]) {
             System.out.printf("%6d", sales);
         }
         System.out.println();
     }
     System.out.println();

     
     for (int i = 0; i < boats.length; i++) {
         System.out.printf("Total boat sales for %s: %d\n", boats[i], totalSales[i]);
     }

     
     String topBoat = boatSales.TopSellingBoat(boats, totalSales);
     System.out.println("\nTop-performing boat: " + topBoat);
 }

@Override
public int TotalBoatSales(int[] boats, int[] totalSales) {
	// TODO Auto-generated method stub
	return 0;
}
}
