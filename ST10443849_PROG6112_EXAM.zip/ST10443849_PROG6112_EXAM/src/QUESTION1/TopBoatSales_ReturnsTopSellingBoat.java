package QUESTION1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TopBoatSales_ReturnsTopSellingBoat {
	public void TopBoatSales_ReturnsTopSellingBoat() {
        // Arrange
        String[] boatTypes = {"Bowrider", "Catamaran", };
        int[] sales = {10, 25, 15}; // Example sales: Catamaran is the top-selling boat
        BoatSalesData[] boatSalesData = new BoatSalesData[boatTypes.length];

        // Populate sales data
        for (int i = 0; i < boatTypes.length; i++) {
            boatSalesData[i] = new BoatSalesData(boatTypes[i], 100000 + i * 5000); // Price changes by 5000 per boat
        }

        // Act
        String topSellingBoat = getTopSellingBoat(boatTypes, sales);

        // Assert
        assertEquals("Catamaran", topSellingBoat);
    }

    // Helper method to calculate the top-selling boat
    private String getTopSellingBoat(String[] boatTypes, int[] sales) {
        int maxSales = 0;
        String topBoat = "";
        for (int i = 0; i < sales.length; i++) {
            if (sales[i] > maxSales) {
                maxSales = sales[i];
                topBoat = boatTypes[i];
            }
        }
        return topBoat;
    }

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
