package QUESTION1;

//Interface containing the data provided on the question paper
public interface IBoatSales {
	int TotalBoatSales(int[]boats, int[] totalSales);
	String TopSellingBoat(String[]boats, int[]totalSales);

}
