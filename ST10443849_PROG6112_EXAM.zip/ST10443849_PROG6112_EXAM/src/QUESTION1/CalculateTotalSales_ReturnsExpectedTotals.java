package QUESTION1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculateTotalSales_ReturnsExpectedTotals {
	

	    @Test
	    public void CalculateTotalSales_ReturnsExpectedTotalSales() {
	        // Arrange
	        BoatSales boatSales = new BoatSales();
	        double boatPrice = 200000.00; // Example boat price

	        // Act
	        double totalWithVAT = boatSales.CalculateTotal(boatPrice);

	        // Assert
	        assertEquals(228000.00, totalWithVAT, 0.01); // Expecting 200000 + 14% VAT
	    }

	    
	    


	@Test
	void test() {
		fail("Not yet implemented");
	}

}
